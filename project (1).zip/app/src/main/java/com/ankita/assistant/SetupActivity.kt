package com.ankita.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import java.util.Locale

class SetupActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var memView: TextView
    private val ui = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            if (::status.isInitialized) refresh()
            ui.postDelayed(this, 1500)
        }
    }
    private var testTts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("ankita", MODE_PRIVATE)
        val mem = Memory(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(40, 80, 40, 60)

        fun text(t: String, size: Float = 16f): TextView {
            val v = TextView(this)
            v.text = t
            v.textSize = size
            v.setPadding(0, 16, 0, 8)
            root.addView(v)
            return v
        }

        fun button(t: String, f: () -> Unit) {
            val b = Button(this)
            b.text = t
            b.isAllCaps = false
            b.setOnClickListener { f() }
            root.addView(b)
        }

        text("Ankita Setup", 26f)

        text("1. Gemini API key (aistudio.google.com/apikey)")
        val keyBox = EditText(this)
        keyBox.hint = "AIza..."
        keyBox.setText(prefs.getString("key", ""))
        root.addView(keyBox)
        button("Key save karo") {
            prefs.edit().putString("key", keyBox.text.toString().trim()).apply()
            Dbg.log("Key save hui (" + keyBox.text.toString().trim().length + " akshar)")
            Toast.makeText(this, "Key save ho gayi", Toast.LENGTH_SHORT).show()
        }
        button("Test: Gemini key check karo") {
            val k = prefs.getString("key", "") ?: ""
            Dbg.log("Key test chal raha hai...")
            Thread {
                val r = Gemini.call(k, JSONArray().put(Gemini.userText("Say hello in Hindi in one short sentence")), null, false, false)
                Dbg.log("Key test: " + (r ?: "FAIL (upar Gemini ERROR dekho)"))
            }.start()
        }

        text("2. Permissions")
        button("Permissions do (mic, call, SMS, contacts)") {
            val perms = arrayListOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS,
                Manifest.permission.ANSWER_PHONE_CALLS
            )
            requestPermissions(perms.toTypedArray(), 1)
        }
        button("Display over other apps: ON karo") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
        }
        button("Modify system settings: ON karo (brightness)") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + packageName)))
        }

        text("3. Accessibility (screen control: tap, scroll, type)")
        text("Agar ON nahi ho raha (grey): App info > upar 3 dots > Allow restricted settings.", 13f)
        button("App info kholo") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName)))
        }
        button("Accessibility settings kholo > Ankita ON karo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        text("4. Awaaz test")
        button("Ankita ki awaaz sunao") {
            testTts = TextToSpeech(this) { st ->
                if (st == TextToSpeech.SUCCESS) {
                    testTts?.language = Locale("hi", "IN")
                    testTts?.setPitch(1.25f)
                    testTts?.speak("Namaste, main Ankita hu", TextToSpeech.QUEUE_FLUSH, null, "t")
                } else {
                    Dbg.log("TTS init fail: Google Text-to-speech install/ON karo")
                }
            }
        }

        text("5. Ankita ki memory")
        memView = text("", 14f)
        button("Memory dekho / refresh") { memView.text = memText(mem) }
        button("Memory backup (share karo)") {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_TEXT, mem.exportText())
            startActivity(Intent.createChooser(i, "Backup"))
        }
        button("Sirf purani chat delete karo") {
            mem.clearHistory()
            Toast.makeText(this, "Chat delete ho gayi", Toast.LENGTH_SHORT).show()
        }
        button("POORI memory delete karo") {
            mem.clearAll()
            memView.text = memText(mem)
            Toast.makeText(this, "Memory delete ho gayi", Toast.LENGTH_SHORT).show()
        }
        memView.text = memText(mem)

        text("Status / log:")
        status = text("", 13f)
        setContentView(ScrollView(this).also { it.addView(root) })
        refresh()
    }

    private fun memText(mem: Memory): String {
        val f = mem.facts()
        return if (f.isEmpty()) "(abhi kuch yaad nahi)" else f.joinToString("\n") { "- " + it }
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    private fun refresh() {
        val acc = if (AnkitaAccess.instance != null) "ON" else "OFF"
        status.text = "Accessibility: " + acc + "\n\n" + Dbg.dump()
    }
}
