package com.ankita.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import org.json.JSONArray
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var status: TextView
    private val ui = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            if (::status.isInitialized) refresh()
            ui.postDelayed(this, 1500)
        }
    }
    private var testTts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("ankita", MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(40, 80, 40, 60)

        fun text(t: String, size: Float = 16f): TextView {
            val v = TextView(this)
            v.text = t
            v.textSize = size
            v.setPadding(0, 16, 0, 8)
            root.addView(v)
            return v
        }

        fun button(t: String, f: () -> Unit) {
            val b = Button(this)
            b.text = t
            b.isAllCaps = false
            b.setOnClickListener { f() }
            root.addView(b)
        }

        val title = text("Ankita", 30f)
        title.gravity = Gravity.CENTER
        text("Hindi / Bengali / English voice assistant")

        text("Step 1: Gemini API key (aistudio.google.com)")
        val keyBox = EditText(this)
        keyBox.hint = "AIza..."
        keyBox.setText(prefs.getString("key", ""))
        root.addView(keyBox)
        button("Key save karo") {
            prefs.edit().putString("key", keyBox.text.toString().trim()).apply()
            Dbg.log("Key save hui (" + keyBox.text.toString().trim().length + " akshar)")
            Toast.makeText(this, "Key save ho gayi", Toast.LENGTH_SHORT).show()
        }

        text("Step 2: Permissions")
        button("Permissions do (mic, call, SMS, contacts)") {
            val perms = arrayListOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS,
                Manifest.permission.ANSWER_PHONE_CALLS
            )
            if (Build.VERSION.SDK_INT >= 33) perms.add("android.permission.POST_NOTIFICATIONS")
            requestPermissions(perms.toTypedArray(), 1)
        }
        button("Display over other apps: ON karo") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
        }
        button("Modify system settings: ON karo (brightness)") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + packageName)))
        }
        button("Battery: Unrestricted karo") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + packageName)))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        text("Step 3: Accessibility (tap, scroll, type ke liye)")
        text("Agar ON nahi ho raha (grey hai): Settings > Apps > Ankita > 3 dots (upar) > Allow restricted settings. Phir wapas yahan aao.", 13f)
        button("App info kholo (restricted settings ke liye)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName)))
        }
        button("Accessibility settings kholo > Ankita ON karo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        text("Step 4: Chalu karo")
        button("START Ankita") {
            startForegroundService(Intent(this, ListenService::class.java))
            Toast.makeText(this, "Ankita chalu", Toast.LENGTH_SHORT).show()
            refresh()
        }
        button("STOP Ankita") {
            val i = Intent(this, ListenService::class.java)
            i.action = ListenService.ACTION_STOP
            startService(i)
            refresh()
        }

        text("Step 5: Test (agar kaam na kare)")
        button("Test 1: Ankita ki awaaz sunao") {
            testTts = TextToSpeech(this) { st ->
                if (st == TextToSpeech.SUCCESS) {
                    testTts?.language = Locale("hi", "IN")
                    testTts?.setPitch(1.3f)
                    testTts?.speak("Namaste, main Ankita hu", TextToSpeech.QUEUE_FLUSH, null, "t")
                } else {
                    Dbg.log("TTS init fail: phone me Google Text-to-speech install/ON karo")
                }
            }
        }
        button("Test 2: Gemini key check karo") {
            val k = prefs.getString("key", "") ?: ""
            Dbg.log("Key test chal raha hai...")
            Thread {
                val r = Gemini.call(k, JSONArray().put(Gemini.userText("Say hello in Hindi in one short sentence")), null, false, false)
                Dbg.log("Key test: " + (r ?: "FAIL (upar Gemini ERROR dekho)"))
            }.start()
        }
        text("Live log (kya ho raha hai):")
        status = text("")
        setContentView(ScrollView(this).also { it.addView(root) })
        refresh()
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    private fun refresh() {
        val acc = if (AnkitaAccess.instance != null) "ON" else "OFF"
        status.text = "Accessibility: " + acc + "\nService: " + (if (ListenService.running) "chal rahi hai" else "band hai") + "\n\n" + Dbg.dump()
    }
}
