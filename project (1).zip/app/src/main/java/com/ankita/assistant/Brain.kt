package com.ankita.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Brain(
    private val ctx: Context,
    private val mem: Memory,
    private val actions: Actions,
    private val confirm: (String, String) -> Boolean,
    private val keyProvider: () -> String
) {
    private val INFO = setOf("battery", "time", "read_screen", "web_answer")

    private val SYSTEM = """You are Ankita, a warm, cheerful, caring young woman who is the user's personal AI friend and phone assistant.
You chat naturally like a real friend: friendly, curious, a little playful, never robotic. Notice the user's mood and respond kindly.
Use the user's name if you know it. Ask a short follow-up question sometimes to keep the chat going.
Understand Hindi, Bengali, English and Hinglish. Always reply in the SAME language as the user's latest message.
Reply ONLY with JSON:
{"lang":"hi|bn|en","say":"your spoken reply (1-4 short sentences, no emoji, no markdown)","actions":[{"tool":"...","args":{...}}]}
Use Devanagari for Hindi, Bengali script for Bengali, English for English.
Use actions only when the user wants something done on the phone. For pure chat, actions = [].
MEMORY: when the user tells you something worth remembering (name, likes, dislikes, family, routine, important dates, goals), add action remember{fact} with a short clear sentence. If the user corrects or asks to forget something, use forget{fact} (a keyword of the old fact) and then remember the corrected one. Use the 'Known facts' below naturally in conversation.
Tools:
remember{fact}  forget{fact}
open_app{name: app name in English as shown on the phone, e.g. WhatsApp, YouTube, Chrome, Camera}
call{who: contact name or number}  sms{to,text}  open_url{url}  search{q}  youtube{q}
key{name: play_pause|next|prev|volume_up|volume_down|mute|home|back|recents|power|answer_call|end_call|screenshot}
swipe{direction: up|down|left|right}  tap_text{text: visible text of a button on screen}  type_text{text}  press_enter{}
toggle{what: wifi|bluetooth|torch|mobile_data|airplane|dnd|rotation, on: true|false}
brightness{level 0-100}  volume{level 0-100}  alarm{hour,minute,label}  timer{seconds}
settings{page: wifi|bluetooth|display|sound|battery|location|apps|main}  wait{seconds}
INFO tools (their result comes back to you): battery{} time{} read_screen{} web_answer{q}
Use web_answer for news, facts, weather, or anything needing the internet.
For multi-step phone tasks chain actions in one list, e.g. WhatsApp message: open_app, wait 3, tap_text (search or chat name), wait 1, tap_text (contact), type_text, press_enter.
"""

    private fun systemPrompt(): String {
        val f = mem.facts()
        val facts = if (f.isEmpty()) "(nothing yet)" else f.joinToString("\n") { "- " + it }
        val now = SimpleDateFormat("EEEE dd MMMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
        return SYSTEM + "\nKnown facts about the user:\n" + facts + "\nCurrent date and time: " + now + "\n"
    }

    /** Worker thread par chalao. onSay(text, lang) UI par bolne/dikhane ke liye. */
    fun handle(userText: String, onSay: (String, String) -> Unit) {
        val key = keyProvider()
        if (key.isEmpty()) {
            onSay("Pehle Setup me jaakar Gemini key daalo.", "hi")
            return
        }
        val history = mem.history()
        history.add(Gemini.userText(userText))
        val raw = Gemini.call(key, JSONArray(history), systemPrompt(), true, false)
        if (raw == null) {
            history.removeAt(history.size - 1)
            onSay("Mujhe internet ya key me dikkat lag rahi hai. Setup me Test chalao.", "hi")
            return
        }
        val plan = try {
            JSONObject(raw)
        } catch (e: Exception) {
            JSONObject().put("lang", "hi").put("say", raw.take(300)).put("actions", JSONArray())
        }
        history.add(Gemini.modelText(raw))
        mem.saveHistory(history)

        val lang = plan.optString("lang", "hi")
        val say = plan.optString("say", "")
        if (say.isNotEmpty()) onSay(say, lang)

        val infos = ArrayList<String>()
        val acts = plan.optJSONArray("actions") ?: JSONArray()
        for (i in 0 until acts.length()) {
            val act = acts.getJSONObject(i)
            val tool = act.optString("tool")
            val args = act.optJSONObject("args") ?: JSONObject()
            Dbg.log("TOOL " + tool + " " + args)
            var res: String? = null
            try {
                when (tool) {
                    "remember" -> mem.add(args.optString("fact"))
                    "forget" -> mem.remove(args.optString("fact"))
                    "call" -> {
                        if (confirm(args.optString("who") + " ko call karun?", lang)) {
                            res = actions.run(tool, args, lang)
                        }
                    }
                    else -> res = actions.run(tool, args, lang)
                }
            } catch (e: Exception) {
                res = "error " + e.message
            }
            if (res != null) Dbg.log("-> " + res)
            if (res != null && (tool in INFO || res.contains("not") || res.contains("error") || res.contains("off") || res.contains("need"))) {
                infos.add(tool + ": " + res)
            }
        }
        if (infos.isNotEmpty()) {
            val c = JSONArray().put(Gemini.userText(
                "Tool results:\n" + infos.joinToString("\n") +
                "\nTell the user briefly, friendly, in language code " + lang + ", max 3 sentences, plain text only."))
            val r = Gemini.call(key, c, "You are Ankita, a warm young woman assistant. Plain text only.", false, false)
            onSay(r ?: infos.joinToString("; "), lang)
        }
    }
}
