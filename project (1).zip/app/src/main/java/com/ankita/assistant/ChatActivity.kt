package com.ankita.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

class ChatActivity : Activity() {

    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var statusTv: TextView
    private lateinit var micBtn: Button
    private lateinit var convBtn: Button
    private lateinit var bgBtn: Button
    private val langBtns = ArrayList<Button>()

    private lateinit var mem: Memory
    private lateinit var brain: Brain
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private val ui = Handler(Looper.getMainLooper())
    private val pending = AtomicInteger(0)

    private var langTag = "hi-IN"
    private var convMode = false
    private var foreground = false
    private var retries = 0

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun prefKey(): String = getSharedPreferences("ankita", MODE_PRIVATE).getString("key", "") ?: ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mem = Memory(this)
        langTag = getSharedPreferences("ankita", MODE_PRIVATE).getString("lang", "hi-IN") ?: "hi-IN"
        val actions = Actions(this, { prefKey() }, { m, l -> confirmDialog(m, l) })
        brain = Brain(this, mem, actions, { m, l -> confirmDialog(m, l) }, { prefKey() })

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#101418"))
        root.setPadding(dp(8), dp(36), dp(8), dp(8))

        // header
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "Ankita"
        title.textSize = 24f
        title.setTextColor(Color.WHITE)
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val setup = Button(this)
        setup.text = "Setup"
        setup.isAllCaps = false
        setup.setOnClickListener { startActivity(Intent(this, SetupActivity::class.java)) }
        head.addView(setup)
        root.addView(head)

        // language row
        val langRow = LinearLayout(this)
        langRow.orientation = LinearLayout.HORIZONTAL
        val langs = listOf("हिंदी" to "hi-IN", "বাংলা" to "bn-IN", "English" to "en-IN")
        for ((label, tag) in langs) {
            val b = Button(this)
            b.text = label
            b.isAllCaps = false
            b.setOnClickListener {
                langTag = tag
                getSharedPreferences("ankita", MODE_PRIVATE).edit().putString("lang", tag).apply()
                paintLang()
            }
            langBtns.add(b)
            langRow.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(langRow)

        convBtn = Button(this)
        convBtn.isAllCaps = false
        convBtn.setOnClickListener { convMode = !convMode; paintConv() }
        root.addView(convBtn)

        bgBtn = Button(this)
        bgBtn.isAllCaps = false
        bgBtn.setOnClickListener { toggleBg() }
        root.addView(bgBtn)

        statusTv = TextView(this)
        statusTv.setTextColor(Color.parseColor("#9AA4B2"))
        statusTv.textSize = 13f
        statusTv.setPadding(dp(8), dp(4), dp(8), dp(4))
        root.addView(statusTv)

        // chat area
        chat = LinearLayout(this)
        chat.orientation = LinearLayout.VERTICAL
        scroll = ScrollView(this)
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // bottom bar
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        input = EditText(this)
        input.hint = "Yahan likho ya mic dabao"
        input.setTextColor(Color.WHITE)
        input.setHintTextColor(Color.parseColor("#6B7280"))
        input.imeOptions = EditorInfo.IME_ACTION_SEND
        input.setOnEditorActionListener { _, _, _ -> submitInput(); true }
        bar.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val send = Button(this)
        send.text = "Bhejo"
        send.isAllCaps = false
        send.setOnClickListener { submitInput() }
        bar.addView(send)
        micBtn = Button(this)
        micBtn.text = "Mic"
        micBtn.isAllCaps = false
        micBtn.setOnClickListener { startListening() }
        bar.addView(micBtn)
        root.addView(bar)

        setContentView(root)
        paintLang()
        paintConv()
        setStatus("Ready")

        tts = TextToSpeech(this) { st ->
            ttsReady = (st == TextToSpeech.SUCCESS)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { ui.post { setStatus("Bol rahi hu...") } }
                override fun onDone(utteranceId: String?) { spoken() }
                override fun onError(utteranceId: String?) { spoken() }
            })
        }

        restoreChat()
        if (chat.childCount == 0) {
            bubble("Hi! Main Ankita hu. Mujhse kuch bhi poocho, baat karo, ya phone ka koi kaam bolo.", false)
        }
        if (prefKey().isEmpty()) {
            bubble("Pehle upar Setup dabao aur Gemini key daalo.", false)
        }
    }

    override fun onResume() {
        super.onResume()
        foreground = true
        ListenService.paused = true
        paintBg()
    }

    override fun onPause() {
        foreground = false
        ListenService.paused = false
        recognizer?.destroy()
        recognizer = null
        super.onPause()
    }

    override fun onDestroy() {
        tts?.shutdown()
        recognizer?.destroy()
        super.onDestroy()
    }

    // ---------- UI helpers ----------
    private fun paintLang() {
        val tags = listOf("hi-IN", "bn-IN", "en-IN")
        for (i in langBtns.indices) {
            langBtns[i].alpha = if (tags[i] == langTag) 1f else 0.45f
        }
    }

    private fun paintConv() {
        convBtn.text = if (convMode) "Baat-cheet mode: ON (jawab ke baad khud sunegi)" else "Baat-cheet mode: OFF"
    }

    private fun paintBg() {
        bgBtn.text = if (ListenService.running) "Background mode: ON (app band karke bolo: Ankita ...)" else "Background mode: OFF (dabao ON karne ko)"
    }

    private fun toggleBg() {
        if (ListenService.running) {
            val i = Intent(this, ListenService::class.java)
            i.action = ListenService.ACTION_STOP
            startService(i)
            ui.postDelayed({ paintBg() }, 600)
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, "android.permission.POST_NOTIFICATIONS"), 8)
            return
        }
        if (prefKey().isEmpty()) {
            bubble("Pehle Setup me Gemini key daalo.", false)
            return
        }
        startForegroundService(Intent(this, ListenService::class.java))
        bubble("Background mode ON. Ab Home dabao aur bolo: Ankita, ...", false)
        ui.postDelayed({ paintBg() }, 800)
    }

    private fun setStatus(s: String) {
        statusTv.text = s
    }

    private fun bubble(text: String, user: Boolean) {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 16f
        tv.setTextColor(Color.WHITE)
        tv.setPadding(dp(14), dp(10), dp(14), dp(10))
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.8).toInt()
        val bg = GradientDrawable()
        bg.cornerRadius = dp(18).toFloat()
        bg.setColor(Color.parseColor(if (user) "#2B5CFF" else "#2A2F36"))
        tv.background = bg
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = if (user) Gravity.END else Gravity.START
        lp.setMargins(dp(6), dp(4), dp(6), dp(4))
        chat.addView(tv, lp)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun restoreChat() {
        for (h in mem.history().takeLast(12)) {
            try {
                val t = h.getJSONArray("parts").getJSONObject(0).optString("text")
                if (h.optString("role") == "user") {
                    bubble(t, true)
                } else {
                    val say = JSONObject(t).optString("say")
                    if (say.isNotEmpty()) bubble(say, false)
                }
            } catch (e: Exception) {
            }
        }
    }

    // ---------- speaking ----------
    private fun speak(text: String, lang: String) {
        val t = tts ?: return
        if (!ttsReady) return
        val clean = text.replace(Regex("[*_#`]"), "")
        val loc = when (lang) {
            "bn" -> Locale("bn", "IN")
            "en" -> Locale("en", "IN")
            else -> Locale("hi", "IN")
        }
        t.language = loc
        t.setPitch(1.25f)
        pending.incrementAndGet()
        t.speak(clean, TextToSpeech.QUEUE_ADD, null, "u" + System.nanoTime())
    }

    private fun spoken() {
        if (pending.decrementAndGet() <= 0) {
            pending.set(0)
            ui.post { afterSpeak() }
        }
    }

    private fun afterSpeak() {
        setStatus("Ready")
        if (convMode && foreground) {
            ui.postDelayed({ if (convMode && foreground) startListening() }, 300)
        }
    }

    // ---------- listening ----------
    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setStatus("Speech recognizer nahi mila: Google app install/update karo")
            return
        }
        tts?.stop()
        pending.set(0)
        recognizer?.destroy()
        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = sr
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { setStatus("Sun rahi hu..."); micBtn.alpha = 0.5f }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { micBtn.alpha = 1f }
            override fun onError(error: Int) {
                micBtn.alpha = 1f
                retries++
                if (convMode && foreground && retries < 2) {
                    ui.postDelayed({ startListening() }, 400)
                } else {
                    retries = 0
                    setStatus("Samajh nahi aaya (error " + error + "). Mic dobara dabao.")
                }
            }
            override fun onResults(results: Bundle?) {
                micBtn.alpha = 1f
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) {
                    retries = 0
                    submit(t)
                } else {
                    setStatus("Kuch suna nahi, dobara bolo")
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null) input.setText(t)
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        sr.startListening(i)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (requestCode == 7) startListening()
            if (requestCode == 8) toggleBg()
        }
    }

    // ---------- sending ----------
    private fun submitInput() {
        val t = input.text.toString().trim()
        if (t.isNotEmpty()) submit(t)
    }

    private fun submit(text: String) {
        input.setText("")
        bubble(text, true)
        setStatus("Soch rahi hu...")
        Thread {
            try {
                brain.handle(text) { say, lang ->
                    runOnUiThread {
                        bubble(say, false)
                        speak(say, lang)
                    }
                }
            } catch (e: Exception) {
                Dbg.log("brain error: " + e.message)
            }
            runOnUiThread { if (pending.get() == 0) afterSpeak() }
        }.start()
    }

    private fun confirmDialog(msg: String, lang: String): Boolean {
        val latch = CountDownLatch(1)
        var ans = false
        runOnUiThread {
            speak(msg, lang)
            AlertDialog.Builder(this)
                .setMessage(msg)
                .setCancelable(false)
                .setPositiveButton("Haan") { _, _ -> ans = true; latch.countDown() }
                .setNegativeButton("Nahi") { _, _ -> latch.countDown() }
                .show()
        }
        latch.await(60, TimeUnit.SECONDS)
        return ans
    }
}
