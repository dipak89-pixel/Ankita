package com.ankita.assistant

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Gemini {
    const val MODEL = "gemini-2.5-flash"

    fun userText(text: String): JSONObject =
        JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text)))

    fun modelText(text: String): JSONObject =
        JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", text)))

    fun call(key: String, contents: JSONArray, system: String?, json: Boolean, search: Boolean): String? {
        return try {
            val body = JSONObject().put("contents", contents)
            if (system != null) {
                body.put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            }
            if (json) body.put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
            if (search) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))

            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/" + MODEL + ":generateContent?key=" + key)
            val c = url.openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.setRequestProperty("Content-Type", "application/json")
            c.doOutput = true
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val resp = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                Log.e("Ankita", "Gemini error " + code + " " + resp)
                Dbg.log("Gemini ERROR " + code + ": " + resp.take(160).replace("\n", " "))
                return null
            }
            val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
            sb.toString()
        } catch (e: Exception) {
            Log.e("Ankita", "Gemini exception", e)
            Dbg.log("Gemini exception: " + e.message)
            null
        }
    }
}
