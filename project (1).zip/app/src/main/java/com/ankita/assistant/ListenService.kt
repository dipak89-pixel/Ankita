package com.ankita.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Background me sunne wali service: "Ankita ..." sunte hi kaam karti hai. */
class ListenService : Service() {

    companion object {
        const val ACTION_STOP = "com.ankita.assistant.STOP"
        const val CHANNEL = "ankita"
        @Volatile
        var running = false
        @Volatile
        var paused = false

        fun ensureChannel(ctx: Context) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Ankita", NotificationManager.IMPORTANCE_LOW))
        }

        fun tapToStartNotification(ctx: Context) {
            ensureChannel(ctx)
            val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, ChatActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(ctx, CHANNEL)
                .setContentTitle("Ankita band hai")
                .setContentText("Tap karke Background mode ON karo")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pi).setAutoCancel(true).build()
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(2, n)
        }

        val WAKE = listOf("ankita", "ankitha", "ankeeta", "angkita", "अंकिता", "अंकीता", "अंकित", "অঙ্কিতা", "অংকিতা", "অঙ্কিতা")
        val YES = listOf("yes", "haan", "han", "ji", "ok", "kar do", "हाँ", "हां", "जी", "हा", "করো", "হ্যাঁ", "হ্যা", "ঠিক")
    }

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var brain: Brain

    private fun prefKey(): String = getSharedPreferences("ankita", MODE_PRIVATE).getString("key", "") ?: ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ensureChannel(this)
        val pi = PendingIntent.getActivity(this, 0, Intent(this, ChatActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Ankita sun rahi hai")
            .setContentText("Bolo: Ankita ...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            Dbg.log("startForeground fail: " + e.message)
            tapToStartNotification(this)
            stopSelf()
            return
        }
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ankita:listen")
        wakeLock?.acquire()

        val actions = Actions(this, { prefKey() }, { m, l -> confirm(m, l) })
        brain = Brain(this, Memory(this), actions, { m, l -> confirm(m, l) }, { prefKey() })
        tts = TextToSpeech(this) { st -> ttsReady = (st == TextToSpeech.SUCCESS) }
        Dbg.log("Background service start hui")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            running = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running && ::brain.isInitialized) {
            running = true
            Thread { loop() }.start()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        tts?.shutdown()
        try { wakeLock?.release() } catch (e: Exception) {}
        super.onDestroy()
    }

    // ---------------- main loop ----------------
    private fun loop() {
        var waited = 0
        while (!ttsReady && waited < 50) { Thread.sleep(100); waited++ }
        speak("Ankita background me chalu hai. Bolo, Ankita.", "hi")
        var activeUntil = 0L
        while (running) {
            try {
                if (paused) { Thread.sleep(600); continue }
                val heard = recognizeOnce()
                if (heard.isNullOrBlank()) { Thread.sleep(250); continue }
                Dbg.log("Suna: " + heard)
                val low = heard.lowercase()
                val w = WAKE.firstOrNull { low.contains(it) }
                var cmd = ""
                if (w != null) {
                    cmd = low.substring(low.indexOf(w) + w.length).trim(' ', ',', '.', '\u0964')
                } else if (System.currentTimeMillis() < activeUntil) {
                    cmd = heard
                } else {
                    continue
                }
                if (cmd.isBlank()) {
                    speak("Ji, boliye", "hi")
                    cmd = recognizeOnce() ?: continue
                }
                brain.handle(cmd) { say, lang -> speak(say, lang) }
                activeUntil = System.currentTimeMillis() + 25000
            } catch (e: Exception) {
                Log.e("Ankita", "loop error", e)
                Dbg.log("loop error: " + e.message)
                Thread.sleep(1000)
            }
        }
    }

    private fun confirm(msg: String, lang: String): Boolean {
        speak(msg, lang)
        val t = (recognizeOnce() ?: "").lowercase()
        return YES.any { t.contains(it) }
    }

    // ---------------- speech in / out ----------------
    private fun recognizeOnce(): String? {
        val latch = CountDownLatch(1)
        var result: String? = null
        var srRef: SpeechRecognizer? = null
        val lang = getSharedPreferences("ankita", MODE_PRIVATE).getString("lang", "hi-IN") ?: "hi-IN"
        Handler(Looper.getMainLooper()).post {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                Dbg.log("Speech recognizer nahi mila (Google app?)")
                latch.countDown()
                return@post
            }
            val sr = SpeechRecognizer.createSpeechRecognizer(this)
            srRef = sr
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    if (error != 6 && error != 7) Dbg.log("ASR error " + error)
                    latch.countDown()
                }
                override fun onResults(results: Bundle?) {
                    result = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    latch.countDown()
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            try {
                sr.startListening(i)
            } catch (e: Exception) {
                Dbg.log("startListening fail: " + e.message)
                latch.countDown()
            }
        }
        latch.await(15, TimeUnit.SECONDS)
        Handler(Looper.getMainLooper()).post { try { srRef?.destroy() } catch (e: Exception) {} }
        return result
    }

    private fun speak(text: String, lang: String) {
        val t = tts ?: return
        if (!ttsReady) return
        val clean = text.replace(Regex("[*_#`]"), "")
        val loc = when (lang) {
            "bn" -> Locale("bn", "IN")
            "en" -> Locale("en", "IN")
            else -> Locale("hi", "IN")
        }
        t.language = loc
        t.setPitch(1.25f)
        val latch = CountDownLatch(1)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { latch.countDown() }
            override fun onError(utteranceId: String?) { latch.countDown() }
        })
        t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
        latch.await(40, TimeUnit.SECONDS)
    }
}
