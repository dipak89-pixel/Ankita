package com.ankita.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

class ListenService : Service() {

    companion object {
        const val ACTION_STOP = "com.ankita.assistant.STOP"
        const val CHANNEL = "ankita"
        @Volatile
        var running = false

        fun ensureChannel(ctx: Context) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Ankita", NotificationManager.IMPORTANCE_LOW))
        }

        fun tapToStartNotification(ctx: Context) {
            ensureChannel(ctx)
            val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(ctx, CHANNEL)
                .setContentTitle("Ankita band hai")
                .setContentText("Tap karke START dabao")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pi).setAutoCancel(true).build()
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(2, n)
        }

        val WAKE = listOf("ankita", "ankitha", "ankeeta", "\u0905\u0902\u0915\u093F\u0924\u093E", "\u0985\u0999\u09CD\u0995\u09BF\u09A4\u09BE", "\u0985\u0982\u0995\u09BF\u09A4\u09BE")
    }

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wakeLock: PowerManager.WakeLock? = null
    private val history = ArrayList<JSONObject>()
    private lateinit var actions: Actions

    private val SYSTEM = """You are Ankita, a friendly young woman voice assistant that controls an Android phone.
Understand the user's command in Hindi, Bengali, English or Hinglish. Reply ONLY with JSON:
{"lang":"hi|bn|en","say":"short spoken reply in the SAME language as the user (no emoji, no markdown)","actions":[{"tool":"...","args":{...}}]}
Use Bengali script for Bengali, Devanagari for Hindi, English for English. Keep say under 2 sentences.
Use actions only when the user wants something done. For pure chat, actions = [].
Tools:
open_app{name: app name in English as shown on the phone, e.g. WhatsApp, YouTube, Chrome, Camera}
call{who: contact name or number}  sms{to,text}  open_url{url}  search{q}  youtube{q}
key{name: play_pause|next|prev|volume_up|volume_down|mute|home|back|recents|power|answer_call|end_call|screenshot}
swipe{direction: up|down|left|right}  tap_text{text: visible text of a button on screen}  type_text{text}  press_enter{}
toggle{what: wifi|bluetooth|torch|mobile_data|airplane|dnd|rotation, on: true|false}
brightness{level 0-100}  volume{level 0-100}  alarm{hour,minute,label}  timer{seconds}
settings{page: wifi|bluetooth|display|sound|battery|location|apps|main}  wait{seconds}
INFO tools (their result comes back to you): battery{} time{} read_screen{} web_answer{q}
Use web_answer for news, facts, weather, or anything needing the internet.
For multi-step tasks (e.g. WhatsApp message) chain: open_app, wait, tap_text, type_text, press_enter.
"""

    private val AUDIO_RULES = """
The user message is an AUDIO clip. Transcribe it into field "heard".
Set "wake": true only if WAKE_REQUIRED=false or the speech addresses Ankita (Ankita / अंकिता / অঙ্কিতা).
Otherwise return {"wake":false,"heard":"...","actions":[]}.
If only the name was said, wake=true, say a short 'yes, tell me' in the user's language, actions=[].
If the clip is silence, noise, TV or music, wake=false.
"""

    private val INFO = setOf("battery", "time", "read_screen", "web_answer")

    private fun prefKey(): String = getSharedPreferences("ankita", MODE_PRIVATE).getString("key", "") ?: ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ensureChannel(this)
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Ankita sun rahi hai")
            .setContentText("Bolo: Ankita ...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            Log.e("Ankita", "startForeground failed", e)
            tapToStartNotification(this)
            stopSelf()
            return
        }
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ankita:listen")
        wakeLock?.acquire()

        actions = Actions(this, { prefKey() }, { msg, lang -> confirm(msg, lang) })
        tts = TextToSpeech(this) { st -> ttsReady = (st == TextToSpeech.SUCCESS) }
        Dbg.log("Service start hui")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            running = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running && ::actions.isInitialized) {
            running = true
            Thread { loop() }.start()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        tts?.shutdown()
        try { wakeLock?.release() } catch (e: Exception) {}
        super.onDestroy()
    }

    // ---------------- main loop ----------------
    private fun loop() {
        var activeUntil = 0L
        var waited = 0
        while (!ttsReady && waited < 50) { Thread.sleep(100); waited++ }
        Dbg.log("TTS ready = " + ttsReady)
        speak("Namaste, main Ankita hu. Bolo.", "hi")
        Dbg.log("Sun rahi hu... bolo: Ankita, torch on karo")
        while (running) {
            try {
                val key = prefKey()
                val wakeRequired = System.currentTimeMillis() >= activeUntil
                val plan: JSONObject?
                if (isOnline() && key.isNotEmpty()) {
                    val pcm = captureUtterance()
                    if (pcm == null) continue
                    Dbg.log("Awaaz mili (" + (pcm.size / 32) + " ms), Gemini ko bhej rahi hu")
                    plan = thinkAudio(key, pcm, wakeRequired)
                    if (plan == null) Dbg.log("Gemini se jawab nahi aaya") else Dbg.log("Suna: " + plan.optString("heard") + " | wake=" + plan.optBoolean("wake"))
                } else {
                    Dbg.log("Offline mode (internet ya key nahi)")
                    plan = offlinePlan(wakeRequired)
                }
                if (plan == null || !plan.optBoolean("wake", true)) continue
                execute(plan)
                activeUntil = System.currentTimeMillis() + 20000
            } catch (e: Exception) {
                Log.e("Ankita", "loop error", e)
                Thread.sleep(1000)
            }
        }
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    // ---------------- voice capture (VAD) ----------------
    private fun writeShorts(out: ByteArrayOutputStream, f: ShortArray) {
        for (s in f) {
            out.write(s.toInt() and 0xff)
            out.write((s.toInt() shr 8) and 0xff)
        }
    }

    private fun captureUtterance(): ByteArray? {
        val sr = 16000
        val minBuf = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 8192))
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            Dbg.log("MIC start nahi hua (permission/dusra app mic use kar raha?)")
            rec.release()
            Thread.sleep(2000)
            return null
        }
        rec.startRecording()
        val frame = ShortArray(320)
        val out = ByteArrayOutputStream()
        val pre = ArrayDeque<ShortArray>()
        var speaking = false
        var silent = 0
        var speech = 0
        var total = 0
        var noise = 300.0
        try {
            while (running) {
                val n = rec.read(frame, 0, frame.size)
                if (n <= 0) continue
                var sum = 0.0
                for (i in 0 until n) sum += frame[i].toDouble() * frame[i].toDouble()
                val rms = sqrt(sum / n)
                val copy = frame.copyOf(n)
                if (!speaking) {
                    noise = noise * 0.98 + rms * 0.02
                    pre.addLast(copy)
                    if (pre.size > 12) pre.removeFirst()
                    if (rms > maxOf(noise * 2.5, 450.0)) {
                        speaking = true
                        for (f in pre) writeShorts(out, f)
                        speech = 1
                        silent = 0
                    }
                } else {
                    writeShorts(out, copy)
                    total++
                    if (rms > maxOf(noise * 1.8, 300.0)) { speech++; silent = 0 } else silent++
                    if (silent > 45 || total > 600) break
                }
            }
        } finally {
            try { rec.stop() } catch (e: Exception) {}
            rec.release()
        }
        return if (running && speech >= 8) out.toByteArray() else null
    }

    private fun wav(pcm: ByteArray): ByteArray {
        val bb = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + pcm.size)
        bb.put("WAVE".toByteArray()); bb.put("fmt ".toByteArray())
        bb.putInt(16); bb.putShort(1); bb.putShort(1)
        bb.putInt(16000); bb.putInt(32000); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(pcm.size); bb.put(pcm)
        return bb.array()
    }

    private fun audioPart(pcm: ByteArray): JSONObject =
        JSONObject().put("inline_data", JSONObject()
            .put("mime_type", "audio/wav")
            .put("data", Base64.encodeToString(wav(pcm), Base64.NO_WRAP)))

    // ---------------- brain ----------------
    private fun thinkAudio(key: String, pcm: ByteArray, wakeRequired: Boolean): JSONObject? {
        val parts = JSONArray()
            .put(JSONObject().put("text", "WAKE_REQUIRED=" + wakeRequired))
            .put(audioPart(pcm))
        val contents = JSONArray()
        history.takeLast(6).forEach { contents.put(it) }
        contents.put(JSONObject().put("role", "user").put("parts", parts))
        val raw = Gemini.call(key, contents, SYSTEM + AUDIO_RULES, true, false) ?: return null
        val plan = try { JSONObject(raw) } catch (e: Exception) { return null }
        val wake = plan.optBoolean("wake", false)
        plan.put("wake", wake)
        if (wake) {
            history.add(Gemini.userText(plan.optString("heard", "")))
            history.add(Gemini.modelText(raw))
            while (history.size > 12) history.removeAt(0)
        }
        return plan
    }

    private fun execute(plan: JSONObject) {
        val lang = plan.optString("lang", "hi")
        val say = plan.optString("say", "")
        if (say.isNotEmpty()) speak(say, lang)
        val infos = ArrayList<String>()
        val acts = plan.optJSONArray("actions") ?: JSONArray()
        for (i in 0 until acts.length()) {
            val act = acts.getJSONObject(i)
            val tool = act.optString("tool")
            val args = act.optJSONObject("args") ?: JSONObject()
            Dbg.log("TOOL " + tool + " " + args)
            val res = try { actions.run(tool, args, lang) } catch (e: Exception) { "error " + e.message }
            if (res != null) Dbg.log("-> " + res)
            if (res != null && (tool in INFO || res.contains("not") || res.contains("error") || res.contains("off") || res.contains("need"))) {
                infos.add(tool + ": " + res)
            }
        }
        if (infos.isNotEmpty()) {
            val key = prefKey()
            val c = JSONArray().put(Gemini.userText(
                "Tool results:\n" + infos.joinToString("\n") +
                "\nTell the user briefly in language code " + lang + ", friendly, max 3 sentences, plain text only."))
            val raw = if (key.isNotEmpty()) Gemini.call(key, c, "You are Ankita, a friendly young woman assistant. Plain text only.", false, false) else null
            speak(raw ?: infos.joinToString("; "), lang)
        }
    }

    private fun confirm(msg: String, lang: String): Boolean {
        speak(msg, lang)
        val key = prefKey()
        if (isOnline() && key.isNotEmpty()) {
            val pcm = captureUtterance() ?: return false
            val parts = JSONArray()
                .put(JSONObject().put("text", "Did the speaker agree / say yes (Hindi, Bengali or English)? Answer only YES or NO."))
                .put(audioPart(pcm))
            val r = Gemini.call(key, JSONArray().put(JSONObject().put("role", "user").put("parts", parts)), null, false, false)
            return r != null && r.uppercase().contains("YES")
        }
        val t = (recognizeOnce() ?: "").lowercase()
        return listOf("yes", "haan", "han", "ji", "ok", "हाँ", "हां", "जी", "হ্যাঁ", "হ্যা", "ঠিক").any { t.contains(it) }
    }

    // ---------------- speech out ----------------
    private fun speak(text: String, lang: String) {
        val t = tts ?: return
        if (!ttsReady) return
        val clean = text.replace(Regex("[*_#`]"), "")
        val loc = when (lang) {
            "bn" -> Locale("bn", "IN")
            "en" -> Locale("en", "IN")
            else -> Locale("hi", "IN")
        }
        t.language = loc
        t.setPitch(1.3f)
        val latch = CountDownLatch(1)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { latch.countDown() }
            override fun onError(utteranceId: String?) { latch.countDown() }
        })
        t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
        latch.await(40, TimeUnit.SECONDS)
    }

    // ---------------- OFFLINE mode ----------------
    private fun recognizeOnce(): String? {
        val latch = CountDownLatch(1)
        var result: String? = null
        Handler(Looper.getMainLooper()).post {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                latch.countDown()
                return@post
            }
            val sr = SpeechRecognizer.createSpeechRecognizer(this)
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { sr.destroy(); latch.countDown() }
                override fun onResults(results: Bundle?) {
                    result = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    sr.destroy()
                    latch.countDown()
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            sr.startListening(i)
        }
        latch.await(15, TimeUnit.SECONDS)
        return result
    }

    private fun offlinePlan(wakeRequired: Boolean): JSONObject? {
        val heard = recognizeOnce()
        if (heard.isNullOrBlank()) { Thread.sleep(700); return null }
        var cmd: String = heard
        val low = heard.lowercase()
        val w = WAKE.firstOrNull { low.contains(it) }
        if (w != null) cmd = heard.lowercase().replaceFirst(w, "").trim(' ', ',', '.')
        else if (wakeRequired) return null
        if (cmd.isBlank()) return JSONObject().put("lang", "hi").put("say", "Ji, boliye").put("actions", JSONArray())
        return localPlan(cmd)
    }

    private fun act(tool: String, vararg kv: Pair<String, Any>): JSONObject {
        val args = JSONObject()
        kv.forEach { args.put(it.first, it.second) }
        return JSONObject().put("tool", tool).put("args", args)
    }

    private fun localPlan(text: String): JSONObject {
        val t = text.lowercase()
        val lang = if (Regex("[\\u0980-\\u09FF]").containsMatchIn(t)) "bn" else "hi"
        fun has(vararg w: String) = w.any { t.contains(it) }
        val off = has("off", "band", "बंद", "বন্ধ")
        val done = mapOf("hi" to "Ho gaya", "bn" to "হয়ে গেছে")
        val acts = JSONArray()
        when {
            has("torch", "टॉर्च", "টর্চ") -> acts.put(act("toggle", "what" to "torch", "on" to !off))
            has("wifi", "वाईफाई", "ওয়াইফাই") -> acts.put(act("toggle", "what" to "wifi", "on" to !off))
            has("bluetooth", "ब्लूटूथ", "ব্লুটুথ") -> acts.put(act("toggle", "what" to "bluetooth", "on" to !off))
            has("pause", "रोको", "रुक", "থামাও", "play", "चलाओ", "চালাও") -> acts.put(act("key", "name" to "play_pause"))
            has("next", "अगला", "পরের") -> acts.put(act("key", "name" to "next"))
            has("volume up", "आवाज बढ़ा", "বাড়াও") -> acts.put(act("key", "name" to "volume_up"))
            has("volume down", "आवाज कम", "কমাও") -> acts.put(act("key", "name" to "volume_down"))
            has("home", "होम", "হোম") -> acts.put(act("key", "name" to "home"))
            has("back", "पीछे", "পেছনে") -> acts.put(act("key", "name" to "back"))
            has("battery", "बैटरी", "ব্যাটারি") ->
                return JSONObject().put("lang", lang).put("say", actions.run("battery", JSONObject(), lang) ?: "").put("actions", JSONArray())
            has("time", "समय", "সময়", "टाइम") ->
                return JSONObject().put("lang", lang).put("say", actions.run("time", JSONObject(), lang) ?: "").put("actions", JSONArray())
            else -> {
                val call = Regex("(?:call|कॉल|কল)\\s+(.+)").find(t) ?: Regex("(.+?)\\s+(?:ko\\s+)?(?:call|कॉल|কল)").find(t)
                val open = Regex("(?:open|ओपन)\\s+(.+)").find(t) ?: Regex("(.+?)\\s*(?:kholo|खोलो|খোলো|খুলো)").find(t)
                if (call != null) acts.put(act("call", "who" to call.groupValues[1].replace("karo", "").replace("ko", "").trim()))
                else if (open != null) acts.put(act("open_app", "name" to open.groupValues[1].trim()))
            }
        }
        if (acts.length() == 0) {
            return JSONObject().put("lang", lang).put("say", "Ye command offline me samajh nahi payi").put("actions", JSONArray())
        }
        return JSONObject().put("lang", lang).put("say", done[lang] ?: "Done").put("actions", acts)
    }
}
