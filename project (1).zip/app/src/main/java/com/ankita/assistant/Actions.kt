package com.ankita.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Actions(
    private val ctx: Context,
    private val keyProvider: () -> String,
    private val confirm: (String, String) -> Boolean
) {
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun start(i: Intent): Boolean {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            val c: Context = AnkitaAccess.instance ?: ctx
            c.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun global(action: Int): Boolean = AnkitaAccess.instance?.performGlobalAction(action) ?: false

    private fun mediaKey(code: Int) {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun findApp(name: String): Intent? {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(q, 0)
        val n = name.lowercase().trim()
        if (n.isEmpty()) return null
        var best = list.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
        if (best == null) {
            best = list.firstOrNull {
                val l = it.loadLabel(pm).toString().lowercase()
                l.contains(n) || (l.length > 2 && n.contains(l))
            }
        }
        if (best == null) return null
        return pm.getLaunchIntentForPackage(best.activityInfo.packageName)
    }

    private fun findContact(name: String): String? {
        return try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                arrayOf("%" + name.trim() + "%"), null
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }

    private fun torch(on: Boolean): String? {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "no flash"
            cm.setTorchMode(id, on)
            null
        } catch (e: Exception) {
            "torch error"
        }
    }

    private fun tileToggle(labels: List<String>): String? {
        val acc = AnkitaAccess.instance ?: return "accessibility off"
        global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
        Thread.sleep(1000)
        var ok = false
        for (l in labels) {
            if (acc.tapText(l)) { ok = true; break }
        }
        Thread.sleep(500)
        global(AccessibilityService.GLOBAL_ACTION_BACK)
        global(AccessibilityService.GLOBAL_ACTION_HOME)
        return if (ok) null else "tile not found"
    }

    fun run(tool: String, a: JSONObject, lang: String): String? {
        val on = a.optBoolean("on", true)
        when (tool) {
            "open_app" -> {
                val i = findApp(a.optString("name")) ?: return "app not found"
                if (!start(i)) return "cannot open app (overlay permission?)"
            }
            "call" -> {
                val who = a.optString("who")
                val num = if (who.replace("+", "").replace(" ", "").all { it.isDigit() } && who.isNotBlank()) who.replace(" ", "")
                          else findContact(who) ?: return "contact not found"
                start(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + num)))
            }
            "sms" -> {
                val to = a.optString("to")
                val num = if (to.replace("+", "").all { it.isDigit() } && to.isNotBlank()) to
                          else findContact(to) ?: return "contact not found"
                val text = a.optString("text")
                if (confirm(text + " - bhejun?", lang)) {
                    val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
                             else SmsManager.getDefault()
                    sm.sendMultipartTextMessage(num, null, sm.divideMessage(text), null, null)
                }
            }
            "open_url" -> start(Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url"))))
            "search" -> start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + URLEncoder.encode(a.optString("q"), "UTF-8"))))
            "youtube" -> start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + URLEncoder.encode(a.optString("q"), "UTF-8"))))
            "key" -> {
                when (a.optString("name")) {
                    "play_pause" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                    "next" -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
                    "prev" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
                    "volume_up" -> repeat(3) { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
                    "volume_down" -> repeat(3) { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
                    "mute" -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI)
                    "home" -> if (!global(AccessibilityService.GLOBAL_ACTION_HOME)) return "accessibility off"
                    "back" -> if (!global(AccessibilityService.GLOBAL_ACTION_BACK)) return "accessibility off"
                    "recents" -> if (!global(AccessibilityService.GLOBAL_ACTION_RECENTS)) return "accessibility off"
                    "power" -> if (!global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)) return "accessibility off"
                    "screenshot" -> if (!global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)) return "accessibility off"
                    "answer_call" -> try {
                        (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).acceptRingingCall()
                    } catch (e: Exception) { return "call permission error" }
                    "end_call" -> try {
                        (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).endCall()
                    } catch (e: Exception) { return "call permission error" }
                }
            }
            "swipe" -> (AnkitaAccess.instance ?: return "accessibility off").swipe(a.optString("direction", "down"))
            "tap_text" -> {
                val acc = AnkitaAccess.instance ?: return "accessibility off"
                if (!acc.tapText(a.optString("text"))) return "text not found on screen"
            }
            "type_text" -> {
                val acc = AnkitaAccess.instance ?: return "accessibility off"
                if (!acc.typeText(a.optString("text"))) return "no text field focused"
            }
            "press_enter" -> (AnkitaAccess.instance ?: return "accessibility off").pressEnter()
            "toggle" -> {
                when (a.optString("what")) {
                    "torch" -> return torch(on)
                    "wifi" -> return tileToggle(listOf("Wi-Fi", "Wi\u2011Fi", "Internet", "WiFi"))
                    "bluetooth" -> return tileToggle(listOf("Bluetooth"))
                    "mobile_data" -> return tileToggle(listOf("Mobile data", "Data"))
                    "airplane" -> return tileToggle(listOf("Airplane mode", "Flight mode", "Airplane"))
                    "dnd" -> return tileToggle(listOf("Do not disturb", "DND"))
                    "rotation" -> return tileToggle(listOf("Auto-rotate", "Auto rotate", "Rotation"))
                }
            }
            "brightness" -> {
                if (!Settings.System.canWrite(ctx)) return "need modify-system-settings permission"
                val lvl = (a.optDouble("level", 50.0) * 2.55).toInt().coerceIn(1, 255)
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, lvl)
            }
            "volume" -> {
                val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, (a.optDouble("level", 50.0) * max / 100).toInt(), AudioManager.FLAG_SHOW_UI)
            }
            "alarm" -> start(Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour", 7))
                .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Ankita"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "timer" -> start(Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "settings" -> {
                val act = when (a.optString("page")) {
                    "wifi" -> Settings.ACTION_WIFI_SETTINGS
                    "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                    "display" -> Settings.ACTION_DISPLAY_SETTINGS
                    "sound" -> Settings.ACTION_SOUND_SETTINGS
                    "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                    "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                    "apps" -> Settings.ACTION_APPLICATION_SETTINGS
                    else -> Settings.ACTION_SETTINGS
                }
                start(Intent(act))
            }
            "wait" -> Thread.sleep((a.optDouble("seconds", 1.0).coerceAtMost(8.0) * 1000).toLong())
            // ---- info tools ----
            "battery" -> {
                val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                return "battery " + bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + " percent"
            }
            "time" -> return SimpleDateFormat("EEEE dd MMMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
            "read_screen" -> return (AnkitaAccess.instance ?: return "accessibility off").readScreen()
            "web_answer" -> {
                val c = JSONArray().put(Gemini.userText(a.optString("q")))
                return Gemini.call(keyProvider(), c, null, false, true) ?: "no internet"
            }
        }
        return null
    }
}
