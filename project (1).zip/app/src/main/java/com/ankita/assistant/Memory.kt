package com.ankita.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Memory(ctx: Context) {
    private val p = ctx.getSharedPreferences("ankita_mem", Context.MODE_PRIVATE)

    fun facts(): MutableList<String> {
        val out = ArrayList<String>()
        try {
            val a = JSONArray(p.getString("facts", "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) {
        }
        return out
    }

    private fun saveFacts(l: List<String>) {
        p.edit().putString("facts", JSONArray(l).toString()).apply()
    }

    fun add(f: String) {
        val t = f.trim()
        if (t.isEmpty()) return
        val l = facts()
        if (!l.contains(t)) l.add(t)
        saveFacts(l.takeLast(200))
    }

    fun remove(q: String) {
        val k = q.lowercase().trim()
        if (k.isEmpty()) return
        saveFacts(facts().filter { !it.lowercase().contains(k) })
    }

    fun clearAll() {
        p.edit().remove("facts").remove("hist").apply()
    }

    fun history(): MutableList<JSONObject> {
        val out = ArrayList<JSONObject>()
        try {
            val a = JSONArray(p.getString("hist", "[]"))
            for (i in 0 until a.length()) out.add(a.getJSONObject(i))
        } catch (e: Exception) {
        }
        return out
    }

    fun saveHistory(h: List<JSONObject>) {
        val t = ArrayList<JSONObject>(h.takeLast(40))
        while (t.isNotEmpty() && t[0].optString("role") != "user") t.removeAt(0)
        p.edit().putString("hist", JSONArray(t).toString()).apply()
    }

    fun clearHistory() {
        p.edit().remove("hist").apply()
    }

    fun exportText(): String = "FACTS:\n" + facts().joinToString("\n") + "\n\nCHAT:\n" +
        history().joinToString("\n") { it.optString("role") + ": " + it.toString().take(300) }
}
