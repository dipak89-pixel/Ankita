package com.ankita.assistant

import android.util.Log
import java.text.SimpleDateFormat
import java.util.ArrayList
import java.util.Date
import java.util.Locale

object Dbg {
    private val buf = ArrayList<String>()

    @Synchronized
    fun log(s: String) {
        Log.d("Ankita", s)
        buf.add(SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) + " " + s)
        while (buf.size > 25) buf.removeAt(0)
    }

    @Synchronized
    fun dump(): String = buf.joinToString("\n")
}
